CREATE DATABASE IF NOT EXISTS ph_billing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ph_billing;

DROP TABLE IF EXISTS invoice_items;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(150) NOT NULL,
 address VARCHAR(255),
 contact_no VARCHAR(50),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 product_name VARCHAR(150) NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL DEFAULT 0,
 stock INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_id INT NOT NULL,
 invoice_date DATETIME NOT NULL,
 subtotal DECIMAL(12,2) NOT NULL,
 discount DECIMAL(12,2) NOT NULL DEFAULT 0,
 vat DECIMAL(12,2) NOT NULL DEFAULT 0,
 total_amount DECIMAL(12,2) NOT NULL,
 payment_method VARCHAR(50) NOT NULL,
 FOREIGN KEY(customer_id) REFERENCES customers(id)
);

CREATE TABLE invoice_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 invoice_id INT NOT NULL,
 product_id INT NOT NULL,
 quantity INT NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 FOREIGN KEY(invoice_id) REFERENCES invoices(id),
 FOREIGN KEY(product_id) REFERENCES products(id)
);

INSERT INTO customers(customer_name,address,contact_no) VALUES
('Juan Dela Cruz','Bacolod City, Negros Occidental','0917-123-4567'),
('Maria Santos','Talisay City, Negros Occidental','0920-987-6543'),
('Pedro Reyes','Silay City, Negros Occidental','0918-456-7890'),
('Ana Garcia','Bacolod City, Negros Occidental','0998-321-4567'),
('Ramon Trading','Mandalagan, Bacolod City','034-434-8899'),
('ABC Computer Shop','Lacson Street, Bacolod City','0917-555-1122'),
('Sunrise Bakery','Talisay City, Negros Occidental','0922-333-7788'),
('Negros Office Supply','Bacolod City, Negros Occidental','0916-444-9090');

INSERT INTO products(product_name,unit_price,stock) VALUES
('Rice 25kg',1450.00,20),
('Cooking Oil 1L',95.00,50),
('Instant Noodles',15.00,100),
('Canned Sardines',28.00,80),
('Coffee 3-in-1',12.00,150),
('Sugar 1kg',78.00,40),
('USB Keyboard',450.00,15),
('USB Mouse',350.00,20),
('Computer Repair Service',500.00,30),
('Printer Ink Black',850.00,10),
('Bond Paper A4',220.00,35),
('Office Folder',35.00,100),
('Ballpen',12.00,200),
('Photocopy Service',3.00,500),
('Document Printing',10.00,300);

INSERT INTO invoices(customer_id,invoice_date,subtotal,discount,vat,total_amount,payment_method) VALUES
(1,'2026-10-01 09:15:00',3170.00,0.00,380.40,3550.40,'Cash'),
(2,'2026-10-01 10:30:00',1230.00,30.00,144.00,1344.00,'GCash'),
(3,'2026-10-02 13:20:00',1850.00,50.00,216.00,2016.00,'Cash'),
(4,'2026-10-03 14:05:00',2650.00,100.00,306.00,2856.00,'Bank Transfer'),
(5,'2026-10-03 15:40:00',4280.00,0.00,513.60,4793.60,'Credit'),
(6,'2026-10-04 09:25:00',1700.00,50.00,198.00,1848.00,'GCash'),
(7,'2026-10-04 11:10:00',960.00,0.00,115.20,1075.20,'Cash'),
(8,'2026-10-05 16:45:00',2300.00,100.00,264.00,2464.00,'Cash');

INSERT INTO invoice_items(invoice_id,product_id,quantity,unit_price,amount) VALUES
(1,1,2,1450,2900),(1,2,2,95,190),(1,5,5,12,60),(1,13,2,12,24),
(2,7,1,450,450),(2,8,1,350,350),(2,11,1,220,220),(2,12,6,35,210),
(3,10,2,850,1700),(3,13,10,12,120),(3,5,2,12,24),(3,3,0,15,0),
(4,7,2,450,900),(4,8,2,350,700),(4,9,2,500,1000),(4,13,4,12,48),(4,14,1,3,3),
(5,11,10,220,2200),(5,12,20,35,700),(5,13,30,12,360),(5,15,10,10,100),(5,10,1,850,850),(5,4,3,28,84),
(6,9,2,500,1000),(6,10,1,850,850),(6,13,10,12,120),(6,14,10,3,30),
(7,1,0,1450,0),(7,2,5,95,475),(7,3,20,15,300),(7,5,10,12,120),(7,4,2,28,56),(7,13,1,12,12),
(8,11,5,220,1100),(8,12,10,35,350),(8,13,20,12,240),(8,15,20,10,200),(8,9,1,500,500),(8,14,10,3,30);
