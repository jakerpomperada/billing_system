<?php
require_once "../config/database.php";
$id=(int)$_GET['id'];
$q=mysqli_query($conn,"SELECT i.*,c.customer_name,c.address,c.contact_no FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.id=$id");
$inv=mysqli_fetch_assoc($q);
$items=mysqli_query($conn,"SELECT ii.*,p.product_name FROM invoice_items ii JOIN products p ON p.id=ii.product_id WHERE ii.invoice_id=$id");
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Invoice</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"><style>@media print{.no-print{display:none!important}}body{font-family:Arial}.invoice{max-width:800px;margin:30px auto}</style></head><body><div class="invoice">
<div class="text-center"><h2>PHILIPPINE BUSINESS STORE</h2><p>Sales Invoice / Official Billing Record<br>Philippines</p></div>
<div class="row"><div class="col-6"><b>Customer:</b> <?= htmlspecialchars($inv['customer_name']) ?><br><?= htmlspecialchars($inv['address']) ?><br><?= htmlspecialchars($inv['contact_no']) ?></div><div class="col-6 text-right"><b>Invoice No.:</b> INV-<?= str_pad($id,6,'0',STR_PAD_LEFT) ?><br><b>Date:</b> <?= date('M d, Y h:i A',strtotime($inv['invoice_date'])) ?><br><b>Payment:</b> <?= htmlspecialchars($inv['payment_method']) ?></div></div><hr>
<table class="table table-bordered"><thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th>Amount</th></tr></thead><tbody><?php while($it=mysqli_fetch_assoc($items)): ?><tr><td><?= htmlspecialchars($it['product_name']) ?></td><td><?= $it['quantity'] ?></td><td>₱<?= number_format($it['unit_price'],2) ?></td><td>₱<?= number_format($it['amount'],2) ?></td></tr><?php endwhile; ?></tbody></table>
<div class="row justify-content-end"><div class="col-5"><table class="table"><tr><th>Subtotal</th><td>₱<?= number_format($inv['subtotal'],2) ?></td></tr><tr><th>Discount</th><td>₱<?= number_format($inv['discount'],2) ?></td></tr><tr><th>VAT 12%</th><td>₱<?= number_format($inv['vat'],2) ?></td></tr><tr><th>Total</th><td><b>₱<?= number_format($inv['total_amount'],2) ?></b></td></tr></table></div></div>
<p class="text-center">Thank you for your business!</p><button onclick="window.print()" class="btn btn-primary no-print">Print</button> <a href="dashboard.php" class="btn btn-secondary no-print">Back</a>
</div></body></html>