<?php
require_once "../config/database.php";

if(isset($_POST['save_invoice'])){
    $customer_id=(int)$_POST['customer_id'];
    $payment=mysqli_real_escape_string($conn,$_POST['payment_method']);
    $subtotal=(float)$_POST['subtotal'];
    $discount=(float)$_POST['discount'];
    $vat=(float)$_POST['vat'];
    $total=(float)$_POST['total'];

    mysqli_query($conn,"INSERT INTO invoices(customer_id,invoice_date,subtotal,discount,vat,total_amount,payment_method)
        VALUES($customer_id,NOW(),$subtotal,$discount,$vat,$total,'$payment')");
    $invoice_id=mysqli_insert_id($conn);

    foreach($_POST['product_id'] as $i=>$pid){
        $pid=(int)$pid;
        $qty=(int)$_POST['qty'][$i];
        $price=(float)$_POST['price'][$i];
        $amount=$qty*$price;

        if($pid > 0 && $qty > 0){
            mysqli_query($conn,"INSERT INTO invoice_items(invoice_id,product_id,quantity,unit_price,amount)
                VALUES($invoice_id,$pid,$qty,$price,$amount)");
            mysqli_query($conn,"UPDATE products SET stock=stock-$qty WHERE id=$pid");
        }
    }

    header("Location: print_invoice.php?id=".$invoice_id);
    exit;
}

$customers=mysqli_query($conn,"SELECT * FROM customers ORDER BY customer_name");
$products=mysqli_query($conn,"SELECT * FROM products WHERE stock>0 ORDER BY product_name");
include "../includes/header.php";
?>

<style>
.billing-item {
    border: 1px solid #dee2e6;
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 10px;
    background: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,.06);
}
.billing-item:hover {
    border-color: #80bdff;
}
.item-number {
    font-weight: bold;
    color: #007bff;
    padding-top: 8px;
}
.price-display, .amount-display {
    font-weight: 600;
    text-align: right;
}
#grandTotal {
    font-size: 28px;
    color: #007bff;
}
</style>

<div class="card card-primary">
<div class="card-header">
    <h3 class="card-title"><i class="fas fa-file-invoice-dollar"></i> Dynamic New Sales Invoice</h3>
</div>

<div class="card-body">
<form method="post" id="billingForm">

<div class="row">
    <div class="col-md-6">
        <label>Customer</label>
        <select name="customer_id" class="form-control" required>
            <option value="">Select customer</option>
            <?php while($c=mysqli_fetch_assoc($customers)): ?>
                <option value="<?= $c['id'] ?>">
                    <?= htmlspecialchars($c['customer_name']) ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>

    <div class="col-md-3">
        <label>Payment Method</label>
        <select name="payment_method" class="form-control">
            <option>Cash</option>
            <option>GCash</option>
            <option>Bank Transfer</option>
            <option>Credit</option>
        </select>
    </div>

    <div class="col-md-3">
        <label>Invoice Date</label>
        <input type="text" class="form-control" value="<?= date('M d, Y h:i A') ?>" readonly>
    </div>
</div>

<hr>

<div class="d-flex justify-content-between align-items-center mb-2">
    <h5 class="mb-0"><i class="fas fa-shopping-cart"></i> Billing Items</h5>
    <button type="button" id="addItem" class="btn btn-success">
        <i class="fas fa-plus"></i> Add Product
    </button>
</div>

<div id="itemsContainer"></div>

<div class="alert alert-info mt-3">
    <i class="fas fa-info-circle"></i>
    Add multiple products. You can change quantity and unit price directly.
    Use the <b>Delete</b> button to remove an item.
</div>

<div class="row justify-content-end">
<div class="col-md-5">
    <div class="card card-outline card-primary">
        <div class="card-body">
            <div class="form-group row">
                <label class="col-sm-6 col-form-label">Subtotal</label>
                <div class="col-sm-6">
                    <input name="subtotal" id="subtotal" readonly class="form-control text-right">
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-6 col-form-label">Discount</label>
                <div class="col-sm-6">
                    <input name="discount" id="discount" value="0"
                           type="number" step="0.01" min="0"
                           class="form-control text-right">
                </div>
            </div>

            <div class="form-group row">
                <label class="col-sm-6 col-form-label">VAT (12%)</label>
                <div class="col-sm-6">
                    <input name="vat" id="vat" readonly class="form-control text-right">
                </div>
            </div>

            <hr>

            <div class="form-group row mb-0">
                <label class="col-sm-6 col-form-label">TOTAL</label>
                <div class="col-sm-6">
                    <input name="total" id="grandTotal" readonly
                           class="form-control text-right font-weight-bold">
                </div>
            </div>
        </div>
    </div>

    <button name="save_invoice" class="btn btn-primary btn-lg btn-block">
        <i class="fas fa-save"></i> Save & Print Invoice
    </button>
</div>
</div>

</form>
</div>
</div>

<script>
const productOptions = `
<option value="">Select product</option>
<?php
mysqli_data_seek($products,0);
while($p=mysqli_fetch_assoc($products)):
?>
<option value="<?= $p['id'] ?>"
        data-price="<?= $p['unit_price'] ?>"
        data-stock="<?= $p['stock'] ?>">
    <?= htmlspecialchars($p['product_name']) ?> -
    ₱<?= number_format($p['unit_price'],2) ?>
    (Stock: <?= $p['stock'] ?>)
</option>
<?php endwhile; ?>
`;

let itemCounter = 0;

function addItem() {
    itemCounter++;

    const div = document.createElement('div');
    div.className = 'billing-item';
    div.dataset.item = itemCounter;

    div.innerHTML = `
        <div class="row align-items-end">

            <div class="col-md-1">
                <label>Item</label>
                <div class="item-number">#${itemCounter}</div>
            </div>

            <div class="col-md-4">
                <label>Product / Service</label>
                <select name="product_id[]" class="form-control product-select" required>
                    ${productOptions}
                </select>
            </div>

            <div class="col-md-2">
                <label>Quantity</label>
                <input name="qty[]" type="number" min="1" value="1"
                       class="form-control qty">
            </div>

            <div class="col-md-2">
                <label>Unit Price</label>
                <input name="price[]" type="number" step="0.01" min="0"
                       class="form-control price">
            </div>

            <div class="col-md-2">
                <label>Amount</label>
                <input readonly class="form-control amount-display">
            </div>

            <div class="col-md-1">
                <button type="button"
                        class="btn btn-danger btn-block delete-item"
                        title="Delete item">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `;

    document.getElementById('itemsContainer').appendChild(div);
    calculateTotals();
}

function calculateTotals() {
    let subtotal = 0;

    document.querySelectorAll('.billing-item').forEach(item => {
        const qty = parseFloat(item.querySelector('.qty').value) || 0;
        const price = parseFloat(item.querySelector('.price').value) || 0;
        const amount = qty * price;

        item.querySelector('.amount-display').value =
            '₱' + amount.toLocaleString('en-PH', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });

        subtotal += amount;
    });

    const discount = parseFloat(document.getElementById('discount').value) || 0;
    const taxable = Math.max(0, subtotal - discount);
    const vat = taxable * 0.12;
    const total = taxable + vat;

    document.getElementById('subtotal').value = subtotal.toFixed(2);
    document.getElementById('vat').value = vat.toFixed(2);
    document.getElementById('grandTotal').value = total.toFixed(2);
}

document.getElementById('addItem').addEventListener('click', addItem);

document.addEventListener('change', function(e) {
    if (e.target.classList.contains('product-select')) {
        const option = e.target.selectedOptions[0];
        const item = e.target.closest('.billing-item');

        if (option && option.dataset.price) {
            item.querySelector('.price').value = option.dataset.price;
        }

        calculateTotals();
    }
});

document.addEventListener('input', function(e) {
    if (
        e.target.classList.contains('qty') ||
        e.target.classList.contains('price') ||
        e.target.id === 'discount'
    ) {
        calculateTotals();
    }
});

document.addEventListener('click', function(e) {
    const deleteButton = e.target.closest('.delete-item');

    if (deleteButton) {
        const items = document.querySelectorAll('.billing-item');

        if (items.length === 1) {
            alert('At least one billing item is required.');
            return;
        }

        deleteButton.closest('.billing-item').remove();

        document.querySelectorAll('.billing-item').forEach((item, index) => {
            item.querySelector('.item-number').textContent = '#' + (index + 1);
        });

        calculateTotals();
    }
});

// Start with one item box.
addItem();
</script>

<?php include "../includes/footer.php"; ?>
