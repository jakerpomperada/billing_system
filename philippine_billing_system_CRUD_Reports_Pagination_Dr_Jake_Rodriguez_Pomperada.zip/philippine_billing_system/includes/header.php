<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PH Billing System</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
<ul class="navbar-nav"><li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a></li></ul>
<span class="navbar-text font-weight-bold">Philippine Billing System</span><span class="navbar-text ml-auto small text-muted">Programmer: Dr. Jake Rodriguez Pomperada, PhD</span>
</nav>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
<a href="dashboard.php" class="brand-link text-center"><span class="brand-text font-weight-light">PH BILLING</span></a>
<div class="sidebar">
<nav class="mt-2"><ul class="nav nav-pills nav-sidebar flex-column">
<li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p></a></li>
<li class="nav-item"><a href="customers.php" class="nav-link"><i class="nav-icon fas fa-users"></i><p>Customers</p></a></li>
<li class="nav-item"><a href="products.php" class="nav-link"><i class="nav-icon fas fa-box"></i><p>Products</p></a></li>
<li class="nav-item"><a href="billing.php" class="nav-link"><i class="nav-icon fas fa-file-invoice-dollar"></i><p>New Billing</p></a></li>
<li class="nav-item"><a href="invoices.php" class="nav-link"><i class="nav-icon fas fa-receipt"></i><p>Invoices</p></a></li>
<li class="nav-item"><a href="report_pdf.php" target="_blank" class="nav-link"><i class="nav-icon fas fa-chart-bar"></i><p>PDF Reports</p></a></li>
</ul></nav>
</div></aside>
<div class="content-wrapper">
<section class="content-header"><div class="container-fluid"><h1>Billing Management</h1></div></section>
<section class="content"><div class="container-fluid">
