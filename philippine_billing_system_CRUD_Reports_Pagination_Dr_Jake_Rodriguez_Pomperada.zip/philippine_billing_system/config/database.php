<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "ph_billing";

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($conn, "utf8mb4");
?>