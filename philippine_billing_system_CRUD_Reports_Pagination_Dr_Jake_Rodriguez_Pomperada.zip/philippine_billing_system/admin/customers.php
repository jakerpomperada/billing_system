<?php
require_once "../config/database.php";
$message = '';
$message_type = 'success';

if (isset($_POST['save'])) {
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $address = mysqli_real_escape_string($conn, trim($_POST['address']));
    $contact = mysqli_real_escape_string($conn, trim($_POST['contact']));
    mysqli_query($conn, "INSERT INTO customers(customer_name,address,contact_no) VALUES('$name','$address','$contact')");
    header("Location: customers.php?msg=added"); exit;
}
if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $address = mysqli_real_escape_string($conn, trim($_POST['address']));
    $contact = mysqli_real_escape_string($conn, trim($_POST['contact']));
    mysqli_query($conn, "UPDATE customers SET customer_name='$name', address='$address', contact_no='$contact' WHERE id=$id");
    header("Location: customers.php?msg=updated"); exit;
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $check = mysqli_query($conn, "SELECT COUNT(*) AS total FROM invoices WHERE customer_id=$id");
    $used = mysqli_fetch_assoc($check)['total'];
    if ($used > 0) {
        header("Location: customers.php?msg=used"); exit;
    }
    mysqli_query($conn, "DELETE FROM customers WHERE id=$id");
    header("Location: customers.php?msg=deleted"); exit;
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM customers WHERE id=$id");
    $edit = mysqli_fetch_assoc($result);
}
if (isset($_GET['msg'])) {
    $messages = ['added'=>'Customer added successfully.','updated'=>'Customer updated successfully.','deleted'=>'Customer deleted successfully.','used'=>'This customer cannot be deleted because it is already used in an invoice.'];
    $message = $messages[$_GET['msg']] ?? '';
    if ($_GET['msg'] === 'used') $message_type = 'warning';
}
$rows = mysqli_query($conn, "SELECT * FROM customers ORDER BY id DESC");
include "../includes/header.php"; ?>
<div class="card">
<div class="card-header"><h3 class="card-title"><i class="fas fa-users mr-2"></i>Customer Management</h3></div>
<div class="card-body">
<?php if ($message): ?><div class="alert alert-<?= $message_type ?> alert-dismissible fade show"><?= htmlspecialchars($message) ?><button type="button" class="close" data-dismiss="alert">&times;</button></div><?php endif; ?>
<form method="post" class="row">
<?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
<div class="col-md-4"><input name="name" class="form-control" placeholder="Customer name" value="<?= htmlspecialchars($edit['customer_name'] ?? '') ?>" required></div>
<div class="col-md-4"><input name="address" class="form-control" placeholder="Address" value="<?= htmlspecialchars($edit['address'] ?? '') ?>"></div>
<div class="col-md-3"><input name="contact" class="form-control" placeholder="Contact number" value="<?= htmlspecialchars($edit['contact_no'] ?? '') ?>"></div>
<div class="col-md-1">
<?php if ($edit): ?><button name="update" class="btn btn-primary btn-block">Update</button><?php else: ?><button name="save" class="btn btn-success btn-block">Add</button><?php endif; ?>
</div>
</form>
<?php if ($edit): ?><div class="mt-2"><a href="customers.php" class="btn btn-secondary btn-sm">Cancel Edit</a></div><?php endif; ?>
<hr>
<div class="table-responsive"><table class="table table-bordered table-striped"><thead><tr><th>ID</th><th>Name</th><th>Address</th><th>Contact</th><th width="150">Actions</th></tr></thead><tbody>
<?php while($r=mysqli_fetch_assoc($rows)): ?><tr><td><?= $r['id'] ?></td><td><?= htmlspecialchars($r['customer_name']) ?></td><td><?= htmlspecialchars($r['address']) ?></td><td><?= htmlspecialchars($r['contact_no']) ?></td><td class="text-nowrap"><a href="customers.php?edit=<?= $r['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> Edit</a> <a href="customers.php?delete=<?= $r['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this customer? This cannot be undone.');"><i class="fas fa-trash"></i> Delete</a></td></tr><?php endwhile; ?>
</tbody></table></div></div></div>
<?php include "../includes/footer.php"; ?>