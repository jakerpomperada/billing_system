<?php
require_once "../config/database.php";
require_once "../vendor/fpdf/fpdf.php";

$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
$pdf->SetTitle('Sales Report - Philippine Billing System');

$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'PHILIPPINE BUSINESS STORE',0,1,'C');
$pdf->SetFont('Arial','B',13);
$pdf->Cell(0,8,'SALES / BILLING REPORT',0,1,'C');
$pdf->SetFont('Arial','',9);
$pdf->Cell(0,6,'Period: All Recorded Sample Transactions',0,1,'C');
$pdf->Ln(5);

$summary = mysqli_fetch_assoc(mysqli_query($conn,
"SELECT COUNT(*) invoice_count, COALESCE(SUM(subtotal),0) subtotal,
COALESCE(SUM(discount),0) discount, COALESCE(SUM(vat),0) vat,
COALESCE(SUM(total_amount),0) total FROM invoices"));

$pdf->SetFont('Arial','B',10);
$pdf->Cell(45,8,'Total Invoices',1);
$pdf->Cell(45,8,'Subtotal',1);
$pdf->Cell(45,8,'Discount',1);
$pdf->Cell(45,8,'VAT',1);
$pdf->Cell(0,8,'',0,1);
$pdf->SetFont('Arial','',10);
$pdf->Cell(45,8,$summary['invoice_count'],1);
$pdf->Cell(45,8,'PHP '.number_format($summary['subtotal'],2),1);
$pdf->Cell(45,8,'PHP '.number_format($summary['discount'],2),1);
$pdf->Cell(45,8,'PHP '.number_format($summary['vat'],2),1);
$pdf->Ln(12);

$pdf->SetFont('Arial','B',9);
$widths=[22,28,50,28,25,37];
$heads=['Invoice','Date','Customer','Payment','VAT','Total'];
foreach($heads as $i=>$h) $pdf->Cell($widths[$i],8,$h,1,0,'C');
$pdf->Ln();
$pdf->SetFont('Arial','',8);

$q=mysqli_query($conn,"SELECT i.*,c.customer_name FROM invoices i
JOIN customers c ON c.id=i.customer_id ORDER BY i.invoice_date");
while($r=mysqli_fetch_assoc($q)){
    $vals=[
      'INV-'.str_pad($r['id'],6,'0',STR_PAD_LEFT),
      date('M d, Y',strtotime($r['invoice_date'])),
      substr($r['customer_name'],0,26),
      $r['payment_method'],
      'PHP '.number_format($r['vat'],2),
      'PHP '.number_format($r['total_amount'],2)
    ];
    foreach($vals as $i=>$v) $pdf->Cell($widths[$i],8,$v,1,0,$i>=4?'R':'L');
    $pdf->Ln();
}

$pdf->Ln(6);
$pdf->SetFont('Arial','B',11);
$pdf->Cell(0,8,'Grand Total: PHP '.number_format($summary['total'],2),0,1,'R');
$pdf->SetFont('Arial','I',8);
$pdf->Cell(0,6,'Sample educational report - verify BIR requirements before actual business use.',0,1,'C');

$pdf->Output('I','sales_report.pdf');
?>
