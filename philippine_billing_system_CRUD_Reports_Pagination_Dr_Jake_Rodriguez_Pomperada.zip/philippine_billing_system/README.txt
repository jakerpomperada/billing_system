# Philippine Billing System
PHP Procedural + MySQL + AdminLTE 3

## Requirements
- XAMPP (Apache + MySQL)
- PHP 7.4+ / PHP 8.x
- Web browser

## Installation
1. Copy `philippine_billing_system` to `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin.
4. Import `database/ph_billing.sql`.
5. Open: http://localhost/philippine_billing_system/admin/
6. Create customers/products or use the sample records.
7. Use New Billing to create an invoice.

## Included
- AdminLTE dashboard
- Customer management
- Product/inventory management
- Sales invoice creation
- Philippine Peso (₱)
- Cash, GCash, Bank Transfer, Credit payment choices
- 12% VAT calculation example
- Invoice history
- Printable invoice

## Important
This is an educational/sample billing system, not a certified BIR invoicing system. For actual business deployment, consult a Philippine accountant/tax professional and ensure the invoice/receipt workflow and registration comply with current BIR requirements.


## Dynamic Billing Items
The upgraded billing screen supports:
- Add Product dynamically
- Edit quantity dynamically
- Edit unit price dynamically
- Delete billing rows dynamically
- Automatic line-item amount calculation
- Automatic subtotal, discount, 12% VAT and total calculation
- Multiple products in one invoice


## Sample Records
The SQL database now contains 8 sample customers, 15 products/services, and 8 sample invoices with Philippine addresses, payment methods, prices, VAT, discounts, and invoice items.

## PDF Report
- `admin/report_pdf.php` generates a printable PDF sales/billing report from MySQL records.
- `sample_sales_report.pdf` is included as a sample output.
- Open `http://localhost/philippine_billing_system/admin/report_pdf.php` after importing the database.


PROGRAMMER
Dr. Jake Rodriguez Pomperada, PhD

CRUD FEATURES
- Customers: Add, Edit, Delete
- Products: Add, Edit, Delete
- Records already referenced by invoices are protected from deletion to preserve billing history.

REPORT MANAGEMENT UPDATE
- Invoice/Reports page now displays 10 reports per page.
- Added First, Previous, numbered pages, Next, and Last pagination.
- Added Print and Delete actions for each report.
- Delete requires browser confirmation and removes invoice line items safely.
- Added PDF Reports navigation link.
