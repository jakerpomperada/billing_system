<?php
require_once "../config/database.php";
$customers = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM customers"))[0];
$products = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM products"))[0];
$invoices = mysqli_fetch_row(mysqli_query($conn,"SELECT COUNT(*) FROM invoices"))[0];
$sales = mysqli_fetch_row(mysqli_query($conn,"SELECT COALESCE(SUM(total_amount),0) FROM invoices"))[0];
include "../includes/header.php";
?>
<div class="row">
<div class="col-lg-3 col-6"><div class="small-box bg-info"><div class="inner"><h3><?= $customers ?></h3><p>Customers</p></div><div class="icon"><i class="fas fa-users"></i></div></div></div>
<div class="col-lg-3 col-6"><div class="small-box bg-success"><div class="inner"><h3><?= $products ?></h3><p>Products</p></div><div class="icon"><i class="fas fa-box"></i></div></div></div>
<div class="col-lg-3 col-6"><div class="small-box bg-warning"><div class="inner"><h3><?= $invoices ?></h3><p>Invoices</p></div><div class="icon"><i class="fas fa-receipt"></i></div></div></div>
<div class="col-lg-3 col-6"><div class="small-box bg-primary"><div class="inner"><h3>₱<?= number_format($sales,2) ?></h3><p>Total Sales</p></div><div class="icon"><i class="fas fa-peso-sign"></i></div></div></div>
</div>
<div class="card"><div class="card-header"><h3 class="card-title">Philippine-style Billing System</h3></div>
<div class="card-body"><p>This sample is designed for small Philippine businesses such as sari-sari stores, retail shops, service shops, and small offices.</p>
<a href="billing.php" class="btn btn-primary"><i class="fas fa-plus"></i> Create New Billing</a></div></div>
<?php include "../includes/footer.php"; ?>