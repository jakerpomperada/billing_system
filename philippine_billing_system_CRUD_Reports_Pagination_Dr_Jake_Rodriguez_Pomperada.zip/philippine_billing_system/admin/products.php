<?php
require_once "../config/database.php";
$message = '';
$message_type = 'success';

if (isset($_POST['save'])) {
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $price = (float)$_POST['price']; $stock = (int)$_POST['stock'];
    mysqli_query($conn, "INSERT INTO products(product_name,unit_price,stock) VALUES('$name',$price,$stock)");
    header("Location: products.php?msg=added"); exit;
}
if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $name = mysqli_real_escape_string($conn, trim($_POST['name']));
    $price = (float)$_POST['price']; $stock = (int)$_POST['stock'];
    mysqli_query($conn, "UPDATE products SET product_name='$name', unit_price=$price, stock=$stock WHERE id=$id");
    header("Location: products.php?msg=updated"); exit;
}
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $check = mysqli_query($conn, "SELECT COUNT(*) AS total FROM invoice_items WHERE product_id=$id");
    $used = mysqli_fetch_assoc($check)['total'];
    if ($used > 0) {
        header("Location: products.php?msg=used"); exit;
    }
    mysqli_query($conn, "DELETE FROM products WHERE id=$id");
    header("Location: products.php?msg=deleted"); exit;
}

$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM products WHERE id=$id");
    $edit = mysqli_fetch_assoc($result);
}
if (isset($_GET['msg'])) {
    $messages = ['added'=>'Product added successfully.','updated'=>'Product updated successfully.','deleted'=>'Product deleted successfully.','used'=>'This product cannot be deleted because it is already used in an invoice.'];
    $message = $messages[$_GET['msg']] ?? '';
    if ($_GET['msg'] === 'used') $message_type = 'warning';
}
$rows = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");
include "../includes/header.php"; ?>
<div class="card">
<div class="card-header"><h3 class="card-title"><i class="fas fa-box mr-2"></i>Product Management</h3></div>
<div class="card-body">
<?php if ($message): ?><div class="alert alert-<?= $message_type ?> alert-dismissible fade show"><?= htmlspecialchars($message) ?><button type="button" class="close" data-dismiss="alert">&times;</button></div><?php endif; ?>
<form method="post" class="row">
<?php if ($edit): ?><input type="hidden" name="id" value="<?= $edit['id'] ?>"><?php endif; ?>
<div class="col-md-5"><input name="name" class="form-control" placeholder="Product / service name" value="<?= htmlspecialchars($edit['product_name'] ?? '') ?>" required></div>
<div class="col-md-3"><input type="number" step="0.01" min="0" name="price" class="form-control" placeholder="Unit price" value="<?= htmlspecialchars($edit['unit_price'] ?? '') ?>" required></div>
<div class="col-md-2"><input type="number" min="0" name="stock" class="form-control" placeholder="Stock" value="<?= htmlspecialchars($edit['stock'] ?? '0') ?>"></div>
<div class="col-md-2"><?php if ($edit): ?><button name="update" class="btn btn-primary btn-block">Update</button><?php else: ?><button name="save" class="btn btn-success btn-block">Add Product</button><?php endif; ?></div>
</form>
<?php if ($edit): ?><div class="mt-2"><a href="products.php" class="btn btn-secondary btn-sm">Cancel Edit</a></div><?php endif; ?>
<hr>
<div class="table-responsive"><table class="table table-bordered table-striped"><thead><tr><th>ID</th><th>Product</th><th>Price</th><th>Stock</th><th width="150">Actions</th></tr></thead><tbody>
<?php while($r=mysqli_fetch_assoc($rows)): ?><tr><td><?= $r['id'] ?></td><td><?= htmlspecialchars($r['product_name']) ?></td><td>₱<?= number_format($r['unit_price'],2) ?></td><td><?= $r['stock'] ?></td><td class="text-nowrap"><a href="products.php?edit=<?= $r['id'] ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> Edit</a> <a href="products.php?delete=<?= $r['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product? This cannot be undone.');"><i class="fas fa-trash"></i> Delete</a></td></tr><?php endwhile; ?>
</tbody></table></div></div></div>
<?php include "../includes/footer.php"; ?>