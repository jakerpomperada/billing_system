<?php
require_once "../config/database.php";

$message = '';
$message_type = 'success';

// Delete invoice and its line items. Confirmation is required in the browser below.
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id > 0) {
        mysqli_begin_transaction($conn);
        try {
            mysqli_query($conn, "DELETE FROM invoice_items WHERE invoice_id=$id");
            mysqli_query($conn, "DELETE FROM invoices WHERE id=$id");
            mysqli_commit($conn);
            header("Location: invoices.php?msg=deleted");
            exit;
        } catch (Throwable $e) {
            mysqli_rollback($conn);
            header("Location: invoices.php?msg=error");
            exit;
        }
    }
}

if (isset($_GET['msg'])) {
    $messages = [
        'deleted' => 'Invoice/report deleted successfully.',
        'error' => 'Unable to delete the invoice/report.'
    ];
    $message = $messages[$_GET['msg']] ?? '';
    if ($_GET['msg'] === 'error') $message_type = 'danger';
}

// Pagination: 10 reports/invoices per page.
$per_page = 10;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$total_rows = (int)mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM invoices"))[0];
$total_pages = max(1, (int)ceil($total_rows / $per_page));
if ($page > $total_pages) $page = $total_pages;
$offset = ($page - 1) * $per_page;

$rows = mysqli_query($conn, "SELECT i.*,c.customer_name FROM invoices i JOIN customers c ON c.id=i.customer_id ORDER BY i.id DESC LIMIT $offset,$per_page");

include "../includes/header.php"; ?>
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><i class="fas fa-chart-bar mr-2"></i>Reports / Invoice History</h3>
    <div class="card-tools">
      <a target="_blank" href="report_pdf.php" class="btn btn-danger btn-sm"><i class="fas fa-file-pdf"></i> Generate PDF Report</a>
    </div>
  </div>
  <div class="card-body">
    <?php if ($message): ?><div class="alert alert-<?= $message_type ?> alert-dismissible fade show"><?= htmlspecialchars($message) ?><button type="button" class="close" data-dismiss="alert">&times;</button></div><?php endif; ?>

    <div class="alert alert-info py-2">
      <i class="fas fa-info-circle"></i> Showing <strong>10 reports per page</strong>. Use the pagination buttons below to view older reports.
    </div>

    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead><tr><th>Invoice No.</th><th>Date</th><th>Customer</th><th>Payment</th><th>Total</th><th width="210">Action</th></tr></thead>
        <tbody>
        <?php if (mysqli_num_rows($rows) === 0): ?>
          <tr><td colspan="6" class="text-center text-muted">No reports/invoices found.</td></tr>
        <?php else: while($r=mysqli_fetch_assoc($rows)): ?>
          <tr>
            <td>INV-<?= str_pad($r['id'],6,'0',STR_PAD_LEFT) ?></td>
            <td><?= date('M d, Y h:i A',strtotime($r['invoice_date'])) ?></td>
            <td><?= htmlspecialchars($r['customer_name']) ?></td>
            <td><?= htmlspecialchars($r['payment_method']) ?></td>
            <td>₱<?= number_format($r['total_amount'],2) ?></td>
            <td class="text-nowrap">
              <a target="_blank" class="btn btn-sm btn-primary" href="print_invoice.php?id=<?= $r['id'] ?>"><i class="fas fa-print"></i> Print</a>
              <a class="btn btn-sm btn-danger" href="invoices.php?page=<?= $page ?>&delete=<?= $r['id'] ?>" onclick="return confirm('Are you sure you want to delete this report/invoice? This will also delete its billing line items and cannot be undone.');"><i class="fas fa-trash"></i> Delete</a>
            </td>
          </tr>
        <?php endwhile; endif; ?>
        </tbody>
      </table>
    </div>

    <div class="row align-items-center mt-3">
      <div class="col-md-6 mb-2 mb-md-0">
        <small class="text-muted">Page <?= $page ?> of <?= $total_pages ?> | <?= $total_rows ?> total report(s)</small>
      </div>
      <div class="col-md-6">
        <nav aria-label="Reports pagination">
          <ul class="pagination pagination-sm justify-content-md-end mb-0">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="invoices.php?page=1">First</a></li>
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="invoices.php?page=<?= max(1,$page-1) ?>">Previous</a></li>
            <?php
            $start = max(1, $page - 2);
            $end = min($total_pages, $page + 2);
            for ($p=$start; $p<=$end; $p++): ?>
              <li class="page-item <?= $p === $page ? 'active' : '' ?>"><a class="page-link" href="invoices.php?page=<?= $p ?>"><?= $p ?></a></li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>"><a class="page-link" href="invoices.php?page=<?= min($total_pages,$page+1) ?>">Next</a></li>
            <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>"><a class="page-link" href="invoices.php?page=<?= $total_pages ?>">Last</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </div>
</div>
<?php include "../includes/footer.php"; ?>
